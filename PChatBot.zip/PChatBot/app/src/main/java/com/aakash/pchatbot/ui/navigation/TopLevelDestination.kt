package com.aakash.pchatbot.ui.navigation

import androidx.annotation.DrawableRes
import com.aakash.pchatbot.R

sealed class TopLevelDestination(
    val title: String,
    val route: String,
    @DrawableRes val selectedIcon: Int,
    @DrawableRes val unselectedIcon: Int
) {
    object Home : TopLevelDestination(
        title = "Home",
        route = "home",
        selectedIcon = R.drawable.ic_home_filled,
        unselectedIcon = R.drawable.ic_home_outlined
    )

    object Search : TopLevelDestination(
        title = "Search",
        route = "search",
        selectedIcon = R.drawable.ic_search_filled,
        unselectedIcon = R.drawable.ic_search_outlined
    )

    object User : TopLevelDestination(
        title = "User",
        route = "user",
        selectedIcon = R.drawable.ic_user_filled,
        unselectedIcon = R.drawable.ic_user_outlined
    )

    object RepositoryDetails : TopLevelDestination(
        title = "Repository Details",
        route = "repository_details",
        selectedIcon = R.drawable.ic_home_filled,
        unselectedIcon = R.drawable.ic_home_filled
    )

    object UserDetails : TopLevelDestination(
        title = "User Details",
        route = "user_details",
        selectedIcon = R.drawable.ic_user_filled,
        unselectedIcon = R.drawable.ic_user_outlined
    )

    object Settings : TopLevelDestination(
        title = "Settings",
        route = "settings",
        selectedIcon = R.drawable.ic_home_filled,
        unselectedIcon = R.drawable.ic_home_filled
    )

    /**
     * Use this function to pass arguments to navigation destination
     */
    fun withArgs(vararg args: Any): String {
        return buildString {
            append(route)
            args.forEach { arg ->
                append("/$arg")
            }
        }
    }
}

val bottomNavItems = listOf(
    TopLevelDestination.Home,
    TopLevelDestination.Search,
    TopLevelDestination.User
)
