package com.aakash.pchatbot.ui.home.details

import com.aakash.pchatbot.Repository

sealed interface RepositoryDetailsUiState {
    object Empty : RepositoryDetailsUiState
    object Loading : RepositoryDetailsUiState
    data class Success(val data: Repository) : RepositoryDetailsUiState
    data class Error(val msg: String) : RepositoryDetailsUiState
}
