package com.aakash.pchatbot.ui

import androidx.lifecycle.ViewModel
import androidx.paging.PagingData
import com.aakash.pchatbot.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val homeRepository: HomeRepository
) : ViewModel() {

}
