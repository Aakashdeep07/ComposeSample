package com.aakash.pchatbot.ui.home.details

import androidx.lifecycle.ViewModel
import com.aakash.pchatbot.ui.HomeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

@HiltViewModel
class RepositoryDetailsViewModel @Inject constructor(
    private val homeRepository: HomeRepository
) : ViewModel() {
    private val _response: MutableStateFlow<RepositoryDetailsUiState> =
        MutableStateFlow(RepositoryDetailsUiState.Empty)
    val response: StateFlow<RepositoryDetailsUiState> = _response.asStateFlow()

/*    fun getRepository(
        username: String,
        repo: String,
    ) = viewModelScope.launch {
        homeRepository.getRepository(username, repo).collect { response ->
            when (response.status) {
                is Resource.Status.Loading -> {
                    _response.value = RepositoryDetailsUiState.Loading
                }

                is Resource.Status.Success -> {
                    val status = (response.status as Resource.Status.Success)
                    _response.value = RepositoryDetailsUiState.Success(status.data)
                }

                is Resource.Status.Error -> {
                    val error = (response.status as Resource.Status.Error)
                    _response.value = RepositoryDetailsUiState.Error(error.errorMessage)
                }

                else -> {}
            }
        }
    }*/


}



