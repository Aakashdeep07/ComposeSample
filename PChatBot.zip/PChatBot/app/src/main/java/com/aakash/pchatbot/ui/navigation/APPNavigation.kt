package com.aakash.pchatbot.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.aakash.pchatbot.ui.home.HomeScreen
import com.aakash.pchatbot.ui.home.details.RepositoryDetailsViewModel


@Composable
fun MADNavigation(
    modifier: Modifier = Modifier,
    navController: NavHostController,
) {
    NavHost(
        modifier = modifier,
        navController = navController,
        startDestination = TopLevelDestination.Home.route
    ) {
        composable(route = TopLevelDestination.Home.route) { backStackEntry ->
            val homeViewModel: com.aakash.pchatbot.ui.HomeViewModel = hiltViewModel()

            HomeScreen(
                navController = navController
            )
        }

        composable(route = TopLevelDestination.Search.route) { backStackEntry ->
            HomeScreen(
                navController = navController
            )
        }

        composable(route = TopLevelDestination.User.route) { backStackEntry ->
            HomeScreen(
                navController = navController
            )
        }

        composable(
            route = TopLevelDestination.RepositoryDetails.route + "/{username}" + "/{repo}",
            arguments = listOf(
                navArgument(name = "username") {
                    type = NavType.StringType
                },
                navArgument(name = "repo") {
                    type = NavType.StringType
                },
            )
        ) { backStackEntry ->
            val repositoryDetailsViewModel: RepositoryDetailsViewModel = hiltViewModel()

            val username = backStackEntry.arguments?.getString("username")
            val repo = backStackEntry.arguments?.getString("repo")

            if (username != null && repo != null) {
                HomeScreen(
                    navController = navController
                )
            }
        }

        composable(
            route = TopLevelDestination.UserDetails.route + "/{username}",
            arguments = listOf(
                navArgument(name = "username") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val username = backStackEntry.arguments?.getString("username")


        }

        composable(route = TopLevelDestination.Settings.route) { backStackEntry ->

        }
    }
}
