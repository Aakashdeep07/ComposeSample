package com.aakash.pchatbot.ui

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HomeRepository @Inject constructor(

) {
  /*  fun searchRepositories(searchQuery: String): Flow<PagingData<Repository>> =
        Pager(config = PagingConfig(pageSize = 9)) {
            RepositoryDataSource(searchQuery = searchQuery, searchApi = searchApi)
        }.flow

    suspend fun getRepository(
        username: String,
        repo: String,
    ): Flow<Resource<Repository>> {
        return networkResource(
            makeNetworkRequest = { repositoryApi.getRepository(username, repo) },
            onNetworkRequestFailed = { _, _ -> }
        ).flowOn(Dispatchers.IO)
    }*/
}
