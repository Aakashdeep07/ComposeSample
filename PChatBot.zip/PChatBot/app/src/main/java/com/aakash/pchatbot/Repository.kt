package com.aakash.pchatbot

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class Repository(
    val id: Long,
    val name: String,
    val private: Boolean,
     @Json(name = "html_url")
    val url: String,
    val description: String?,
    @Json(name = "created_at")
    val createdAt: String,
    @Json(name = "stargazers_count")
    val numberOfStars: Int,
    @Json(name = "forks_count")
    val numberOfForks: Int,
    val language: String?,
    val visibility: String
)
